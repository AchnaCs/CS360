package com.example.weighttrackingappachna;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class RegistrationActivity extends AppCompatActivity {

    private EditText newUsernameEditText;
    private EditText newPasswordEditText;
    private Button registerButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        newUsernameEditText = findViewById(R.id.newUsername);
        newPasswordEditText = findViewById(R.id.newPassword);
        registerButton = findViewById(R.id.registerButton);

        databaseHelper = new DatabaseHelper(this);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newUsername = newUsernameEditText.getText().toString();
                String newPassword = newPasswordEditText.getText().toString();

                if (databaseHelper.checkUsernameExistsWithoutPassword(newUsername)) {
                    Toast.makeText(RegistrationActivity.this, "Username already exists. Please choose a different one.", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isInserted = databaseHelper.insertData(newUsername, newPassword);
                    if (isInserted) {
                        Toast.makeText(RegistrationActivity.this, "Registration successful. You can now log in.", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegistrationActivity.this, MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(RegistrationActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
